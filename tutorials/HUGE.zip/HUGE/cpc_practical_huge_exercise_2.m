%% CPC 2020 - tutorial H: HUGE - Exercise 2
% 
% 
%% init
rng(8032,'twister')

% define group sizes
sizes = [10 10];
% define signal-to-noise ratio
snr = 1;


%% DCM network structure
% set up the DCM network structure
dcm = struct( );
dcm.n = 3;
dcm.a = logical([ ...
    1 0 0; ...
    1 1 1; ...
    1 1 1; 
]);
dcm.c = false(dcm.n,1);
dcm.c(1,1) = true;
dcm.b = false(dcm.n, dcm.n, 1);
dcm.d = false(dcm.n, dcm.n, 0);


%% experimental stimuli
dcm.U.dt = 2/16;
tmp = tapas_huge_boxcar(dcm.U.dt, 8, 16, 1./4, [12 8]);
dcm.U.u = cell2mat(tmp);
dcm.Y.dt = 16*dcm.U.dt;
dcm.TE = .04;


%% define group-level DCM connectivity
% cluster 1
% set connection strength for first group
dcm.Ep.A = [0 0 0;.5 0 0;.1 .5 0];
dcm.Ep.C = [.7;0;0];
dcm.Ep.B = double(dcm.b);
dcm.Ep.D = double(dcm.d);
dcm.Ep.transit = zeros(dcm.n, 1);
dcm.Ep.decay = zeros(dcm.n, 1);
dcm.Ep.epsilon = 0;
% covariance
tmp = [dcm.a(:);dcm.b(:);dcm.c(:);dcm.d(:)];
dcm.Cp = diag([double(tmp).*.01; ones(2*dcm.n+1, 1)*exp(-6)]);
clusters{1} = dcm;

% cluster 2
% set connection strength for second group
dcm.Ep.A = [0 0 0;.5 0 0;-.25 .5 0];
dcm.Ep.C = [.7;0;0];
dcm.Ep.B = double(dcm.b);
dcm.Ep.D = double(dcm.d);
dcm.Ep.transit = zeros(dcm.n, 1);
dcm.Ep.decay = zeros(dcm.n, 1);
dcm.Ep.epsilon = 0;
% covariance
tmp = [dcm.a(:);dcm.b(:);dcm.c(:);dcm.d(:)];
dcm.Cp = diag([double(tmp).*.01; ones(2*dcm.n+1, 1)*exp(-6)]);
clusters{2} = dcm;


%% generate synthetic data
% create tapas_Huge object and generate synthetic data
obj = tapas_Huge('Tag','top-down vs bottom-up');
obj = obj.simulate(clusters, sizes, 'snr', snr);

figure;
plot(obj.model.mu_k');
xlabel('connectivity parameter index')
title('cluster parameters (true)')

figure;
hold on;
plot(obj.model.theta_c(1:10,:)','b')
plot(obj.model.theta_c(11:20,:)','k')
xlabel('connectivity parameter index')
title('subject parameters (true)')


%% plot sample data
figure;
plot(obj.inputs(1).u)
title('Inputs')
ylabel('input 1')

figure;
for r = 1:3
subplot(3,1,r);
hold on
N = sizes(1);
for n = 1:N
    plot(obj.data(n).bold(:,r),'b');
    plot(obj.data(n+N).bold(:,r),'k');    
end
ylabel(['region ' num2str(r)])

end
drawnow


%% export data to SPM's DCM format
% export generated BOLD time series to SPM's DCM format
[ dcms ] = obj.export();

% fields in the DCM format of SPM
fieldnames(dcms{1})


%% change prior range of cluster means
% create HUGE object
obj = tapas_Huge('Verbose',true);

% TODO: import data for first 10 subjects and invert in EB mode with standard
% parameters
obj = obj.estimate('K',1,'Dcm',dcms(1:10));
% plot
plot(obj);

% TODO: increase tau0 to 10 and invert in EB mode
obj = obj.estimate('PriorVarianceRatio',10);
% plot
plot(obj);

% TODO: increase tau0 to 100 and invert in EB mode
obj = obj.estimate('PriorVarianceRatio',100);
% plot
plot(obj);

% compare the plots for the cluster mean estimates mu_k under different
% settings for tau0. What do you notice?


%% omitting certain parameters from the clustering part
% for this part, use K=2 exclusively

% TODO: create HUGE object, import DCM of all subjects and omit nothing
omt0 = tapas_Huge('Tag','omit nothing',...
% TODO: set prior cluster variance to 0.03 and invert model
omt0 = omt0.estimate(...
plot(omt0)
drawnow

% TODO: create HUGE object, import DCM of all subjects and omit self-connections
ofc = struct();
ofc.a = ...
omt1 = tapas_Huge('Tag','omit self-connections',...
% TODO: set prior cluster variance to 0.03 and invert model
omt1 = omt1.estimate(...
plot(omt1)
drawnow

% TODO: create HUGE object, import DCM of all subjects and omit all endogenous connections except for A31
ofc = struct();
ofc.a = [1,0,0;1,1,1;0,1,1];
omt2 = tapas_Huge('Tag','omit all except a31',...
% TODO: set prior cluster variance to 0.03 and invert model
omt2 = omt2.estimate(...
plot(omt2)
drawnow

% TODO: create HUGE object, import DCM of all subjects and omit all input
% strength parameters 
ofc.c = 1;
omt3 = tapas_Huge('Tag','also omit all of c',...
% TODO: set prior cluster variance to 0.03 and invert model
omt3 = omt3.estimate(...
plot(omt3)
drawnow


%% name-value pairs
% print a list of all name-value pairs and browse through the description
help ...

