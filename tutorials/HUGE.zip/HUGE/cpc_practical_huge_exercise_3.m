%% CPC 2020 - tutorial H: HUGE - exercise 3
% 
% 
%% init
% load time series data
load('sessions_cat.mat')

% separate sessions based on duration (in seconds) provided in
% "session_duration" variable
N = length(session_duration);
cumulative_duration = [0;cumsum(session_duration)];
for n = 1:N
    % copy whole time series
    dcms{n} = DCM;
    
    % TODO: slice BOLD time series
    idx1 = ...
    idx2 = ...
    dcms{n}.Y.y = ...
    
    % TODO: slice stimulus time series 
    idx1 = ...
    idx2 = ...
    dcms{n}.U.u = full(dcms{n}.U.u);
    dcms{n}.U.u = ...
    
end

%% import data and invert model
% TODO: create HUGE object
obj = tapas_Huge(...

% plot sample data
figure;
plot(obj.inputs(1).u)
title('Inputs')
ylabel('input 1')

figure;
for r = 1:3
subplot(3,1,r);
hold on
N = 5;
for n = 1:N
    plot(obj.data(n).bold(:,r));   
end
ylabel(['region ' num2str(r)])

end
drawnow

% TODO: set prior variance to 0.1 and invert in EB mode
obj = obj.estimate(...

% TODO: plot result
...




