%% CPC 2020 - tutorial H: HUGE - exercise 3 data generation
% 
% 
%% init
rng(8032,'twister')

% define group sizes
sizes = [1 1 1 1 1];
% define signal-to-noise ratio
snr = 1;


%% DCM network structure
% set up the DCM network structure
dcm = struct( );
dcm.n = 3;
dcm.a = logical([ ...
    1 0 0; ...
    1 1 1; ...
    1 1 1; 
]);
dcm.c = false(dcm.n,1);
dcm.c(1,1) = true;
dcm.b = false(dcm.n, dcm.n, 1);
dcm.d = false(dcm.n, dcm.n, 0);


%% experimental stimuli
dcm.U.dt = 2/16;
stims = tapas_huge_boxcar(dcm.U.dt, 8*ones(5,1), 16, 1./4, [17 19;16 23;19 21;8 25;13 17]);
dcm.U.u = stims{1};
dcm.Y.dt = 16*dcm.U.dt;
dcm.TE = .04;


%% define group-level DCM connectivity
% session 1
% set connection strength for first group
dcm.Ep.A = [0 0 0;.5 0 0;.1 .5 0];
dcm.Ep.C = [.7;0;0];
dcm.Ep.B = double(dcm.b);
dcm.Ep.D = double(dcm.d);
dcm.Ep.transit = zeros(dcm.n, 1);
dcm.Ep.decay = zeros(dcm.n, 1);
dcm.Ep.epsilon = 0;
% covariance
tmp = [dcm.a(:);dcm.b(:);dcm.c(:);dcm.d(:)];
dcm.Cp = diag([double(tmp).*.0001; ones(2*dcm.n+1, 1)*exp(-6)]);
dcm.U.u = stims{1};
L = length(dcm.U.u);
L = fix(L/16)*16;
dcm.U.u = dcm.U.u(1:L);
clusters{1} = dcm;

% session 2
% set connection strength for second group
dcm.Ep.A = [0 0 0;.5 0 0;.0 .5 0];
dcm.U.u = stims{2};
L = length(dcm.U.u);
L = fix(L/16)*16;
dcm.U.u = dcm.U.u(1:L);
clusters{2} = dcm;

% session 3
% set connection strength for second group
dcm.Ep.A = [0 0 0;.5 0 0;.15 .5 0];
dcm.U.u = stims{3};
L = length(dcm.U.u);
L = fix(L/16)*16;
dcm.U.u = dcm.U.u(1:L);
clusters{3} = dcm;

% session 4
% set connection strength for second group
dcm.Ep.A = [0 0 0;.5 0 0;.3 .5 0];
dcm.U.u = stims{4};
L = length(dcm.U.u);
L = fix(L/16)*16;
dcm.U.u = dcm.U.u(1:L);
clusters{4} = dcm;

% session 5
% set connection strength for second group
dcm.Ep.A = [0 0 0;.5 0 0;.1 .5 0];
dcm.U.u = stims{5};
L = length(dcm.U.u);
L = fix(L/16)*16;
dcm.U.u = dcm.U.u(1:L);
clusters{5} = dcm;


%% generate synthetic data
% create tapas_Huge object and generate synthetic data
obj = tapas_Huge('Tag','top-down vs bottom-up');
obj = obj.simulate(clusters, sizes, 'snr', snr);

figure;
plot(obj.model.mu_k');
xlabel('connectivity parameter index')
title('cluster parameters (true)')

figure;
hold on;
plot(obj.model.theta_c','b')
xlabel('connectivity parameter index')
title('subject parameters (true)')


%% plot sample data
figure;
plot(obj.inputs(1).u)
title('Inputs')
ylabel('input 1')

figure;
for r = 1:3
subplot(3,1,r);
hold on
N = 5;
for n = 1:N
    plot(obj.data(n).bold(:,r));  
end
ylabel(['region ' num2str(r)])

end
drawnow

%% export data to SPM's DCM format
% export generated BOLD time series to SPM's DCM format
[ dcms ] = obj.export();

DCM = dcms{1};
for n = 2:5
    DCM.U.u = [full(DCM.U.u);full(dcms{n}.U.u)];
    DCM.Y.y = [DCM.Y.y;dcms{n}.Y.y];
end

session_duration = zeros(5,1);
for n=1:5
    session_duration(n) = (length(dcms{n}.Y.y)*dcms{n}.Y.dt);
end
