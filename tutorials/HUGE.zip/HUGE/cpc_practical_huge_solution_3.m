%% CPC 2020 - tutorial H: HUGE - Solution to exercise 3
% 
% 
%% init
% load time series data
load('sessions_cat.mat')

% separate sessions based on duration (in seconds) provided in
% "session_duration" variable
N = length(session_duration);
cumulative_duration = [0;cumsum(session_duration)];
for n = 1:N
    % copy whole time series
    dcms{n} = DCM;
    
    % slice BOLD time series
    idx1 = cumulative_duration(n)/DCM.Y.dt + 1;
    idx2 = cumulative_duration(n+1)/DCM.Y.dt;
    dcms{n}.Y.y = dcms{n}.Y.y(idx1:idx2,:);
    
    % slice stimulus time series 
    idx1 = cumulative_duration(n)/DCM.U.dt + 1;
    idx2 = cumulative_duration(n+1)/DCM.U.dt;
    dcms{n}.U.u = full(dcms{n}.U.u);
    dcms{n}.U.u = dcms{n}.U.u(idx1:idx2,:);
    
end

%% import data and invert model
% create HUGE object
obj = tapas_Huge('Tag','sessions','Verbose',true,'Dcm',dcms);

% plot sample data
figure;
plot(obj.inputs(1).u)
title('Inputs')
ylabel('input 1')

figure;
for r = 1:3
subplot(3,1,r);
hold on
N = 5;
for n = 1:N
    plot(obj.data(n).bold(:,r));   
end
ylabel(['region ' num2str(r)])

end
drawnow

% set prior variance to 0.1 and invert in EB mode
obj = obj.estimate('K',1,'PriorClusterVariance',0.1);

% plot result
plot(obj)




