## For MAC users, Make sure you have Xcode installed: https://developer.apple.com/xcode/
install.packages("hBayesDM", dependencies=TRUE)
 
## For Windows users:
# Download Rtools: https://cran.r-project.org/bin/windows/Rtools/
# Then install hBayesDM 
install.packages("hBayesDM", dependencies=TRUE)
