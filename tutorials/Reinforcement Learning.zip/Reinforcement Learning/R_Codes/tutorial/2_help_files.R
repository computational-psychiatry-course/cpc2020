# Load hBayesDM library
library(hBayesDM)

# hBayesDM is documented extensively. To view the tasks/models included in 
# the package, use the following command: 
?hBayesDM
 
# To access individual model files directly, use the same command, but 
# replace the package name with the model name: 
?dd_hyperbolic
 
x=seq(0,10, 1)
y=exp(-x)
plot(x,y, type="l")
 
