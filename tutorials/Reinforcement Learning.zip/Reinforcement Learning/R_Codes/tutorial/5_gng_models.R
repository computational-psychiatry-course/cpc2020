# Locate file path to go/ no-go data
gng_dat <- file.choose()

# Which model generated the go/no-go data? 
output1 = gng_m1(gng_dat...)

# Check convergence!
 
# Compare LOOIC values

# Which model generated the data? 
 
  
