%% Computational Psychiatry Course (CPC) 2020
%
% Tutorial: Regression dynamic causal modeling
% 
% This script describes the use of the regression dynamic causal modeling 
% (rDCM) toolbox for whole-brain effective connectivity analyses. The 
% script demonstrates how to apply the rDCM toolbox for an actual empirical
% dataset (from a single subject).
% 

% ----------------------------------------------------------------------
% 
% stefanf@biomed.ee.ethz.ch
%
% Author: Stefan Fraessle, TNU, UZH & ETHZ - 2020
% Copyright 2020 by Stefan Fraessle <stefanf@biomed.ee.ethz.ch>
%
% Licensed under GNU General Public License 3.0 or later.
% Some rights reserved. See COPYING, AUTHORS.
% 
% ----------------------------------------------------------------------


% get path of function
P     = mfilename('fullpath');
P_ind = strfind(P,'rDCM_empirical_solution');

% load the structural connectome
temp = load(fullfile(P(1:P_ind-1),'fMRI_motor','StructConn.mat'));
args.a = temp.conn;

% load the BOLD signal time series from the LH session
load(fullfile(P(1:P_ind-1),'fMRI_motor','Data_LH.mat'))

% set-up a DCM structure
DCM = tapas_rdcm_model_specification(Y,U,args);

% perform model inversion
[output,~] = tapas_rdcm_estimate(DCM,'r',[],1);

% save the results for the LH session
LH.output = output;

% clear variable
clear U Y DCM output


% load the BOLD signal time series from the RH session
load(fullfile(P(1:P_ind-1),'fMRI_motor','Data_RH.mat'))

% set-up a DCM structure
DCM = tapas_rdcm_model_specification(Y,U,args);

% perform model inversion
[output,~] = tapas_rdcm_estimate(DCM,'r',[],1);

% save the results for the LH session
RH.output = output;


% plot the effect of hand movement condition
plot_effect_of_hand_rDCM(LH,RH)
